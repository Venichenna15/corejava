package com;

public class simpleif {
public static void main(String[]args) {
	char ch='n';
	if(ch=='a'||ch=='A'||ch=='E'||ch=='e'||ch=='i'||ch=='I'||ch=='o'||ch=='O'||ch=='u'||ch=='U') {

System.out.println(ch);

}else {
	System.out.println("not");

}
}

}