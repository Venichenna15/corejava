package com;
public class staticvariable {	
	static int a = 8;
	static int b;
	static int c=5;
	static {
		b= a*c;
	}
	public static void main(String[]args) {
		System.out.println(b);	
	}
}