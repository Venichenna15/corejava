package com;

public class explicttypecasting {
	public static void main(String[]args) {
		float f=10.01f;
		short s=(short)f;
		System.out.print(s);
	}
	}