package com;

public class even {
	public static void main(String[]args) {
		int a[]= {22,3,434,3,421,44,665,7,7};
		for(int i=0; i<=a.length-1;i++) {
			System.out.println("Enter your element in index:"+i);
			for(int i1=0;i1<=a.length-1;i1++) {
				if(a[i1]%2==0) {
					System.out.println("even Elements"+a[i1]);
				}
			}
		}
	}
}

