package com;

public class hirsub extends hirearical {
       public void car1() {
    	   System.out.println("shift");
       }
       public static void main(String[]args) {
    	   hirsub h=new hirsub();
    	   h.car();
    	   h.car1();
       }
}
