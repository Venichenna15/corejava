package com;

public class laptop {

	private String company;
	private String model;
	private int rom;
	private int ram;
    public laptop() {
    	this.company="dell";
    	this.model="advanced";
    	this.rom=8;
    	this.ram=442;
        System.out.println("default laptop id created");
    }
    public laptop(String company,String model,int rom,int ram,int cost) {
    	
    	this.company=company;
    	this.model=model;
    	this.rom=rom;
    	this.ram=ram;
        System.out.println("un default laptop is created:"+company);
    	
  
}
    public void setcompany(String company) {
	this.company=company;

    }
    public void setmodel(String model) {
	this.model=model;

}
    public void setrom(int rom) {
	this.rom=rom;
}
    public void setram(int ram) {
	this.ram=ram;
    }
    public String getcompany() {
    	return company;
    }
    public String getmodel() {
    	return model;
   
    }
    
    public long getrom() {
    	return rom;
    	}
    
    
    public int getram() {
    	return ram;
    }
    public void display() {
    	System.out.println("about laptop");
    	System.out.println("company:"+getcompany());
    	System.out.println("model:"+getmodel());
    	System.out.println("rom:"+getrom());
    	System.out.println("ram:"+getram());

    }
    public static void main(String[]args) {
    	System.out.println("about laptop");
    }
}
    

 

    
    
    
    
    