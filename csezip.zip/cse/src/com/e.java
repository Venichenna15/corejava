package com;

public interface e {
	void e();


}
