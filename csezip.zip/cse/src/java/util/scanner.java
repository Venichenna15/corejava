package java.util;

public class scanner {

}
