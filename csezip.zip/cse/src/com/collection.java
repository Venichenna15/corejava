package com;
import java.util.ArrayList;

public class collection {
	public static void main(String[] args) {
	a.add(1);
	
	}

}
