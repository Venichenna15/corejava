package com;

import java.util.Scanner;

public class arr {
	public static void main(String[] args) {
	Scanner s= new Scanner();
	}
	}
