package com;

public class staticandnonstatic {
  static int a=10;
  int b;
  public static void add() {
	   System.out.println("adding");
	   
  }
  public static void sub() {
	   System.out.println("subtraction");
  }
  public static void main(String[]args) {
	  System.out.println(a);
     
      add();
      staticandnonstatic s=new staticandnonstatic();
      s.b=10;
      System.out.println(s.b);

  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
