package com;

public class objectandclass {
   static String company_name="tcs";
   static String company_location="chennai";
     String emp_name;
     int emp_id;
     int emp_salary;
     public static void developer() {
    	 System.out.println("designation is developer");
    	 
     }
		 public static void tester() {
			 System.out.println("designation is tester");
			 
		 }
		 public static void main(String[]args) {
			 System.out.println(company_name);
			 System.out.println(company_location);
			 objectandclass co=new objectandclass();
			 co.emp_name="MAHESH BOB";
			 System.out.println(co.emp_name);
			 co.emp_id=21;
			 System.out.println(co.emp_id);
			 co.emp_salary=60000;
			 System.out.println(co.emp_salary);
			 developer();
			 System.out.println("__________=");
			 objectandclass co1=new objectandclass();
			 System.out.println(company_name);
			 System.out.println(company_location);
			 co1.emp_name="AA";
			 System.out.println(co1.emp_name);
			 co1.emp_id=234;
			 System.out.println(co1.emp_id);
			 co1.emp_salary=28000;
			 System.out.println(co1.emp_salary);
			 developer();


			 
		 }
}
