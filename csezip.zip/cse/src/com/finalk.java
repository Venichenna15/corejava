package com;

public class finalk implements e{
	public void c() {
		System.out.println("c");
	}
	public void d() {
		System.out.println("d");
	}
	public void e() {
		System.out.println("e");
	}
	public static void main(String[]args) {
		finalk f=new finalk();
		f.c();
		f.d();
		f.e();
	}

}
