package com;

public class arr1 {
      public static void main(String[] args) {
		String[]arr1=new String[20];
		arr1[1]="apple";
		arr1[4]="banana";
		arr1[5]="mango";
		arr1[9]="principle";
		arr1[6]="areoplane";
		for(int i=0;i<=10;i++) {
		System.out.println(arr1[i]);
						
	}
	} 
}

