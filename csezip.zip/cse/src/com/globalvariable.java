package com;

public class globalvariable {
    int b=37;

	public static void main(String[]args) {
		int a=10;
	    int b=7;
	    
	    System.out.println(a);
	    System.out.println(globalvariable.b);
	}  
	}

