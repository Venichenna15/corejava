package com;

public class Main {
	static void checkAge(int age) {
		if (age < 18) {
			throw new ArithmeticException("Acess denid -you must be at least 18 years old");
		}
		else {
			System.out.println("Acess granted - tou are old enough!");
}
	}
	public static void main(String[] args) {
		System.out.println("age");
	}
}

