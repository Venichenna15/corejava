package com;

public class smallestelementinarray {


    public static void main(String[] args) {
        int[] numbers = {25, 17, 3, 4, 58, 21, 7, 13};

        int smallest = numbers[0];

        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] < smallest) {
                smallest = numbers[i];
            }
        }

        System.out.println("The smallest element in the array is: " + smallest);
    }
}

