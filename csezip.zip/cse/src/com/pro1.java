package com;

public class static {
public static void main(String[]args) {
	String name="apple";
	String model="fouth gen"
	String processor="intel core";
	
			
			
			
			
			
			
			
			
			
}
}
