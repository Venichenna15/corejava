package com;
public class localvariable {
	public static void main(String[]args) {
		int a=10;
	    int length = 0;
		for(int i=0;i<=length-1;i++);
	    System.out.println(a);
	}  
	}