package array;

public class classarray {
	public static void main(String[]args) {
		int[]arr=new int[20];
		arr[0]=1;
		arr[1]=23;
	    arr[2]=45;
	    arr[3]=67;
	    arr[4]=457;
	    arr[5]=675;
	    System.out.println(arr[6]);
	    System.out.println("________________");
	    for(int i=0;i<=3;i++) {
		 System.out.println(arr[i]);
	    
	}

}
}
