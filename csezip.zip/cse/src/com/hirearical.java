package com;

public class hirearical {
       public void car() {
    	   System.out.println("shift");
       }
       public static void main(String[]args) {
    	   hirearical h=new hirearical();
    	   h.car();
       }
}
