package com;
public class firstcode {
   public static void main(String[] args) {
	   int a = 58;
	   int b = 37;
	   int result =a+b;
	   System.out.println(result);
   }  
}