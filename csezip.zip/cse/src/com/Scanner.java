package com;

public class Scanner {

}
