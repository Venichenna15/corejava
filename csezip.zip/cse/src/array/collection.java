package array;
import java.util.ArrayList;

public class collection {
	public static void main(String[] args) {
		ArrayList <Integer> a=new ArrayList();
	}
	a.add(1);
	
	}
