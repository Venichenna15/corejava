package com;

public interface d {
	void d();


}
